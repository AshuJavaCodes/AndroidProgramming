package com.example.dropdownmenu;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Toast;

import com.example.dropdownmenu.databinding.ActivityMainBinding;

public class MainActivity extends AppCompatActivity {
    ActivityMainBinding mainBinding;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        mainBinding = ActivityMainBinding.inflate(getLayoutInflater());

        super.onCreate(savedInstanceState);
        setContentView(mainBinding.getRoot());
        String[] items_dropdown = new String[] {"1","2","3"};
        ArrayAdapter<String> adapterx= new ArrayAdapter<>(this,R.layout.support_simple_spinner_dropdown_item,getResources().getStringArray(R.array.programming_languages));
        mainBinding.spinner1.setAdapter(adapterx);
        mainBinding.spinner1.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                if(i==0){
                    getSupportFragmentManager().beginTransaction().replace(R.id.container, new java_frg()).commit();

                } else if(i==1){
                    getSupportFragmentManager().beginTransaction().replace(R.id.container, new kotlin_frg()).commit();

                } else if(i==2){
                    getSupportFragmentManager().beginTransaction().replace(R.id.container, new frg_python()).commit();

                } else if(i==3)
                    getSupportFragmentManager().beginTransaction().replace(R.id.container, new cpp_fragment()).commit();
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {
                Toast.makeText(MainActivity.this, "Nothing Selected", Toast.LENGTH_SHORT).show();
            }
        });


    }
}