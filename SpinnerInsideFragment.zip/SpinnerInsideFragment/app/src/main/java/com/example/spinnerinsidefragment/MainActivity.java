package com.example.spinnerinsidefragment;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.example.spinnerinsidefragment.databinding.ActivityMainBinding;

public class MainActivity extends AppCompatActivity {
    ActivityMainBinding mainBinding;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        getSupportFragmentManager().beginTransaction().replace(R.id.container, new SpinnerFragment()).commit();

    }
}