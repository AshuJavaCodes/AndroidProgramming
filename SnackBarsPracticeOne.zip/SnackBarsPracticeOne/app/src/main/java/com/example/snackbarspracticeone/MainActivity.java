package com.example.snackbarspracticeone;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import com.example.snackbarspracticeone.databinding.ActivityMainBinding;
import com.google.android.material.snackbar.Snackbar;

public class MainActivity extends AppCompatActivity {
    ActivityMainBinding mainBinding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        mainBinding = ActivityMainBinding.inflate(getLayoutInflater());
        super.onCreate(savedInstanceState);
        setContentView(mainBinding.getRoot());

        mainBinding.btnSnackbar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //Simple Snack Bar
                Snackbar.make(view,"This is SnackBar",Snackbar.LENGTH_LONG).show();

            }
        });
        mainBinding.btnSnackbar2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //SnackBar With Action.
                Snackbar.make(view,"This is SnackBar With Action",Snackbar.LENGTH_INDEFINITE).setAction("TOAST", new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        Toast.makeText(MainActivity.this, "Clicked on Toast ! SnackBar Gone.", Toast.LENGTH_SHORT).show();
                    }
                }).show();
            }
        });
    }
}