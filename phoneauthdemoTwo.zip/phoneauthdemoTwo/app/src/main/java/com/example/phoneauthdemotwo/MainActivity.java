package com.example.phoneauthdemotwo;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import com.example.phoneauthdemotwo.databinding.ActivityMainBinding;

public class MainActivity extends AppCompatActivity {
    ActivityMainBinding mainBinding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        mainBinding = ActivityMainBinding.inflate(getLayoutInflater());

        super.onCreate(savedInstanceState);
        setContentView(mainBinding.getRoot());
        mainBinding.idBtnGetOtp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String number = "+91"+mainBinding.idEdtPhoneNumber.getText().toString().trim();
                Intent verifyIntent = new Intent(MainActivity.this, VerifyOtpActivity.class);
                verifyIntent.putExtra("number_key", number);
                startActivity(verifyIntent);
            }
        });
    }
}