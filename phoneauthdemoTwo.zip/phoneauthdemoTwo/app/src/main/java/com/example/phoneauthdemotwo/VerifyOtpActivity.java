package com.example.phoneauthdemotwo;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Toast;

import com.example.phoneauthdemotwo.databinding.ActivityVerifyOtpBinding;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.FirebaseException;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.PhoneAuthCredential;
import com.google.firebase.auth.PhoneAuthOptions;
import com.google.firebase.auth.PhoneAuthProvider;

import java.util.concurrent.TimeUnit;

public class VerifyOtpActivity extends AppCompatActivity {
    ActivityVerifyOtpBinding verifyOtpBinding;
    String otpid;
    String numberGlobal;
    FirebaseAuth mAuth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        verifyOtpBinding = ActivityVerifyOtpBinding.inflate(getLayoutInflater());

        super.onCreate(savedInstanceState);
        setContentView(verifyOtpBinding.getRoot());
        mAuth = FirebaseAuth.getInstance();
        String numberFinal = getIntent().getExtras().getString("number_key");
        numberGlobal = numberFinal;
        processOtp();

        verifyOtpBinding.idBtnVerify.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                /*String numberFinal = getIntent().getExtras().getString("number_key");
                numberGlobal = numberFinal;*/
                //GETTING THE USER ENETERD OTP NUMBER AND PASSING IT TO THE PHONEAUTHPROVIDER OBJ.
                String getEnteredOtp = verifyOtpBinding.idEdtOtp.getText().toString().trim();
                PhoneAuthCredential credentialx = PhoneAuthProvider.getCredential(otpid, getEnteredOtp);
                signInWithPhoneAuthCredential(credentialx);
            }
        });
    }
    private void processOtp(){
        PhoneAuthOptions options =
                PhoneAuthOptions.newBuilder(mAuth)
                        .setPhoneNumber(numberGlobal)       // Phone number to verify
                        .setTimeout(60L, TimeUnit.SECONDS) // Timeout and unit
                        .setActivity(this)                 // Activity (for callback binding)
                        .setCallbacks(new PhoneAuthProvider.OnVerificationStateChangedCallbacks(){
                            @Override
                            public void onVerificationCompleted(PhoneAuthCredential credential) {
                                signInWithPhoneAuthCredential(credential);

                            }
                            @Override
                            public void onVerificationFailed(@NonNull FirebaseException e) {
                                Toast.makeText(VerifyOtpActivity.this, "OnVerficationFailed Toast !", Toast.LENGTH_SHORT).show();

                            }
                            @Override
                            public void onCodeSent(@NonNull String verificationId,
                                                   @NonNull PhoneAuthProvider.ForceResendingToken token) {
                                otpid = verificationId;
                            }

                        })          // OnVerificationStateChangedCallbacks
                        .build();
        PhoneAuthProvider.verifyPhoneNumber(options);




    }
    private void signInWithPhoneAuthCredential(PhoneAuthCredential credential) {
        mAuth.signInWithCredential(credential)
                .addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if (task.isSuccessful()) {
                            Intent dashBoard = new Intent(VerifyOtpActivity.this, LoginDashboardActivity.class);
                            startActivity(dashBoard);

                        } else {
                            Log.w("ErrorWRONGOTPLOG", "signInWithCredential:failure", task.getException());
                            Toast.makeText(VerifyOtpActivity.this, "Wrong Otp Toast. !", Toast.LENGTH_SHORT).show();

                        }
                    }
                });
    }
}